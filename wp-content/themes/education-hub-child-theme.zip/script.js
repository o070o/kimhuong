jQuery(document).ready(function($){

			console.log('Education Hub Child theme loaded');

			console.log('Created by www.template.co.il');

			/* CUSTOM JAVASCRIPT CODE GOES HERE */


		});

