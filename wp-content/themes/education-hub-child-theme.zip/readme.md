How to Use Education Hub child theme

				Extract the files from the .zip archive and upload the files the to /wp-content/themes/ directory

				Or you can upload this .zip file by your wordpress website dashboard under the 'Appearance > Themes' tab.
